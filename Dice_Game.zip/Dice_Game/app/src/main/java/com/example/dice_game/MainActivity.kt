package com.example.dice_game

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    lateinit var gameButton: Button
        override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        gameButton = findViewById(R.id.newGameButton)
        gameButton.setOnClickListener() {
            val intent = Intent(this, Game::class.java)
            startActivity(intent)
        }
    }


}