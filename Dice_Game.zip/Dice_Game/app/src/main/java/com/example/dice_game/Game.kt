package com.example.dice_game

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import java.util.Random

class Game : AppCompatActivity() {
    var scoreTotal = 0
    var scoreTotalComp = 0
    lateinit var scoreText: TextView
    lateinit var rethrowBtn : Button
    lateinit var dice1 : ImageView
    lateinit var dice2 : ImageView
    lateinit var dice3 : ImageView
    lateinit var dice4 : ImageView
    lateinit var dice5 : ImageView
    lateinit var computerDice1 : ImageView
    lateinit var computerDice2 : ImageView
    lateinit var computerDice3 : ImageView
    lateinit var computerDice4 : ImageView
    lateinit var computerDice5 : ImageView
    var playerResultList = mutableListOf<Int>()
    var compResultlist = mutableListOf<Int>()
    var randomNum:Int=0
    lateinit var imageList:ArrayList<Int>
    lateinit var throwbtn: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)
        dice1 = findViewById(R.id.imageView15)
        dice2 = findViewById(R.id.imageView16)
        dice3 = findViewById(R.id.imageView14)
        dice4 = findViewById(R.id.imageView17)
        dice5 = findViewById(R.id.imageView18)
        computerDice1 = findViewById(R.id.imageView11)
        computerDice2 = findViewById(R.id.imageView3)
        computerDice3 = findViewById(R.id.imageView7)
        computerDice4 = findViewById(R.id.imageView12)
        computerDice5 = findViewById(R.id.imageView13)


        imageList = arrayListOf(R.drawable.die_face_1, R.drawable.die_face_2, R.drawable.die_face_3,R.drawable.die_face_4,R.drawable.die_face_5,R.drawable.die_face_6)
        throwbtn = findViewById(R.id.throwBtn)
        throwbtn.setOnClickListener{
            randomNum=Random().nextInt(6)

            playerResultList.add(randomNum+1)
            dice1.setImageResource(imageList[randomNum])
            randomNum=Random().nextInt(6)

            playerResultList.add(randomNum+1)
            dice2.setImageResource(imageList[randomNum])
            randomNum=Random().nextInt(6)

            playerResultList.add(randomNum+1)
            dice3.setImageResource(imageList[randomNum])
            randomNum=Random().nextInt(6)

            playerResultList.add(randomNum+1)
            dice4.setImageResource(imageList[randomNum])
            randomNum=Random().nextInt(6)

            playerResultList.add(randomNum+1)
            dice5.setImageResource(imageList[randomNum])
            randomNum=Random().nextInt(6)

            playerResultList.add(randomNum+1)
            computerDice1.setImageResource(imageList[randomNum])
            randomNum=Random().nextInt(6)

            compResultlist.add(randomNum+1)
            computerDice2.setImageResource(imageList[randomNum])
            randomNum=Random().nextInt(6)

            compResultlist.add(randomNum+1)
            computerDice3.setImageResource(imageList[randomNum])
            randomNum=Random().nextInt(6)
            compResultlist.add(randomNum+1)

            computerDice4.setImageResource(imageList[randomNum])
            randomNum=Random().nextInt(6)
            compResultlist.add(randomNum+1)

            computerDice5.setImageResource(imageList[randomNum])
            compResultlist.add(randomNum+1)




        }



    }

        fun updateScore(correct: Int) {
            scoreText = findViewById(R.id.textView)
        ++scoreTotal

        // display the score
        scoreText.setText("Score: " + scoreTotalComp +"/" + scoreTotal)
}




}